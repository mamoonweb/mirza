<!-- address -->
<div id="contact" class="address">
  <div class="container">
    <div class="agile-title">
      <h3> Contact Us</h3>
    </div>
    <ul>
      <li><i class="fa fa-map-marker" aria-hidden="true"></i>Broome St, Canada, NY 10002, New York</li>
      <li><i class="fa fa-phone" aria-hidden="true"> </i> +01 111 222 3333</li>
      <li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com"> mail@example.com</a></li>
    </ul>
  </div>
</div>
<!-- //address --> 