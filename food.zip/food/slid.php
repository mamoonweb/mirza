<!-- slid -->
<div class="slid">
  <div class="container">
    <h4>Today Special</h4>
    <h5>50% <span>Offer</span></h5>
    <p>In malesuada accumsan felis, a imperdiet arcu blandit sed. Ut id faucibus eros. Fusce sed vulputate dui, non consectetur felis. Etiam id enim sem. Suspendisse commodo tempor magna </p>
  </div>
</div>
<!-- //slid -->