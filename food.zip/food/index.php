<?php

include("header.php");
include("welcome.php");
include("slid.php");
include("menu.php");
include("team.php");
include("foods.php");
include("address.php");
include("contact.php");
include("footer.php");



?>