<!-- welcome -->
<div id="about" class="welcome">
  <div class="container">
    <div class="agile-title">
      <h3> Welcome !</h3>
    </div>
    <div class="w3ls-row">
      <div class="col-md-6 welcome-left">
        <div class="welcome-img"> <img src="images/img1.jpg" class="img-responsive zoom-img" alt=""/> </div>
        <div class="col-md-6 welcome-left-grids">
          <div class="welcome-img"> <img src="images/img2.jpg" class="img-responsive zoom-img" alt=""/> </div>
        </div>
        <div class="col-md-6 welcome-left-grids">
          <div class="welcome-img"> <img src="images/img3.jpg" class="img-responsive zoom-img" alt=""/> </div>
        </div>
        <div class="clearfix"> </div>
      </div>
      <div class="col-md-6 welcome-right">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt lorem sed velit fermentum lobortis. Fusce eu semper lacus, eget placerat mauris. Sed lectus tellus, sodales id elit a, feugiat porttitor nulla. Sed porta magna vitae nisl vulputate lacinia. Morbi malesuada sollicitudin tortor, vitae pharetra nunc lacinia eget. Nulla ornare purus nunc, ut dapibus leo sodales adipiscing. Praesent sit amet justo diam. Quisque sagittis egestas sem vitae vestibulum. Quisque nec lacus ornare, volutpat arcu in lacinia dolor Itaque earum rerum hic tenetur a sapiente delectus . </p>
        <div class="open-hours-row">
          <div class="col-md-3 open-hours-left">
            <h4>OPENING HOURS </h4>
          </div>
          <div class="col-md-3 open-hours-left">
            <h6>BREAKFAST</h6>
            <h5>7am - 12am</h5>
          </div>
          <div class="col-md-3 open-hours-left">
            <h6>MAIN MENU</h6>
            <h5>12am - 12pm</h5>
          </div>
          <div class="col-md-3 open-hours-left">
            <h6>SPECIALS</h6>
            <h5>8pm - 11pm</h5>
          </div>
          <div class="clearfix"> </div>
        </div>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
</div>
<!-- //welcome --> 