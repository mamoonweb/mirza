<script>
alert('Are You Sure');
</script>
<?php
include("config.php");
session_destroy();


?>
<script>
document.location='index.php';
</script>;