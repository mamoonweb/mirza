<footer class="footer">
<div class="container">
<p>Copyright&copy; &amp; Privacy Policy 2017 | Design By : Mirza Mamoon Baig</p>
</div>
</footer>




</body>
</html>