<?php
session_start();

$con=mysqli_connect('localhost','root','','foodpoint') or die (mysqli_error());



?>