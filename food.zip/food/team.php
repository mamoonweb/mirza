<!-- team -->
<div id="team" class="team">
  <div class="container">
    <div class="agile-title">
      <h3> Our Team</h3>
    </div>
    <div class="team-row">
      <div class="col-md-3 team-grids">
        <div class="w3ls-effect"> <img src="images/t11.png" alt="img">
          <div class="view-caption">
            <h4>John Smith</h4>
            <p>Chef</p>
          </div>
          <div class="social-icon"> <a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a> <a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> <a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> </div>
        </div>
      </div>
      <div class="col-md-3 team-grids">
        <div class="w3ls-effect"> <img src="images/t22.png" alt="img">
          <div class="view-caption">
            <h4>Thomson Doe</h4>
            <p>Chef</p>
          </div>
          <div class="social-icon"> <a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a> <a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> <a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> </div>
        </div>
      </div>
      <div class="col-md-3 team-grids">
        <div class="w3ls-effect"> <img src="images/t33.png" alt="img">
          <div class="view-caption">
            <h4>Smith Kevin</h4>
            <p>Chef</p>
          </div>
          <div class="social-icon"> <a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a> <a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> <a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> </div>
        </div>
      </div>
      <div class="col-md-3 team-grids">
        <div class="w3ls-effect"> <img src="images/t44.png" alt="img">
          <div class="view-caption">
            <h4>Laura Hill</h4>
            <p>Chef</p>
          </div>
          <div class="social-icon"> <a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a> <a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a> <a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a> </div>
        </div>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
</div>
<!-- //team --> 