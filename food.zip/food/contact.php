
<!-- contact -->
<div class="contact">
  <div class="col-md-6 contact-left">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57537.641430789925!2d-74.03215321337959!3d40.719122105634035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sin!4v1456152197129" allowfullscreen=""></iframe>
  </div>
  <div class="col-md-6 contact-right">
    <div class="wthree-contact-row">
      <h4>Get In TOuch</h4>
      <form action="#" method="post">
        <input type="text" name="Name" placeholder="Name" required>
        <input class="email" type="text" name="Email" placeholder="Email" required>
        <textarea placeholder="Message" name="Message" required></textarea>
        <input type="submit" value="SUBMIT">
      </form>
    </div>
  </div>
  <div class="clearfix"> </div>
</div>
<!-- //contact --> 